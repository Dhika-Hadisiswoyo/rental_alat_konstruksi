## BuildBuddy, by Srcbook

This app was created using https://srcbook.com.
Need help or want to join the community? Join our [Discord](https://discord.gg/shDEGBSe2d).

To run the devserver:
```
npm install
npm run dev
```
