import { useEffect, useState } from 'react'
import { Save, Trash2, Printer } from 'lucide-react'
import { RentalEntry, Customer, Receipt as ReceiptType } from '../types/types'
import Receipt from '../components/Receipt'

export default function RentalHistoryPage() {
  const [rentals, setRentals] = useState<RentalEntry[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<RentalEntry | null>(null)
  const [showReceipt, setShowReceipt] = useState(false)
  const [currentReceipt, setCurrentReceipt] = useState<ReceiptType | null>(null)

  useEffect(() => {
    const savedRentals = localStorage.getItem('rentals')
    const savedCustomers = localStorage.getItem('customers')
    if (savedRentals) setRentals(JSON.parse(savedRentals))
    if (savedCustomers) setCustomers(JSON.parse(savedCustomers))
  }, [])

  const handleEdit = (rental: RentalEntry) => {
    setEditingId(rental.id)
    setEditForm(rental)
  }

  const handleSave = () => {
    if (!editForm) return
    const updatedRentals = rentals.map(rental => 
      rental.id === editForm.id ? editForm : rental
    )
    setRentals(updatedRentals)
    localStorage.setItem('rentals', JSON.stringify(updatedRentals))
    setEditingId(null)
    setEditForm(null)
  }

  const handleDelete = (id: string) => {
    const updatedRentals = rentals.filter(rental => rental.id !== id)
    setRentals(updatedRentals)
    localStorage.setItem('rentals', JSON.stringify(updatedRentals))
  }

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId)
    return customer ? customer.name : 'Unknown Customer'
  }

  const handlePrintReceipt = (rental: RentalEntry) => {
    const receipt: ReceiptType = {
      id: rental.id,
      date: rental.dateOut,
      customerName: getCustomerName(rental.customerId),
      items: [rental],
      subtotal: rental.price * rental.quantity * (rental.totalDays || 1),
      tax: 0,
      total: rental.price * rental.quantity * (rental.totalDays || 1)
    }
    setCurrentReceipt(receipt)
    setShowReceipt(true)
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Rental History</h1>
        <p className="mt-2 text-gray-600">View and manage all rentals</p>
      </div>

      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Machine</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Out</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Back</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rentals.map((rental) => (
              <tr key={rental.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {editingId === rental.id ? (
                    <select
                      value={editForm?.customerId}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, customerId: e.target.value} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    >
                      {customers.map((customer) => (
                        <option key={customer.id} value={customer.id}>
                          {customer.name}
                        </option>
                      ))}
                    </select>
                  ) : (
                    getCustomerName(rental.customerId)
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {editingId === rental.id ? (
                    <input
                      type="text"
                      value={editForm?.item}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, item: e.target.value} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    />
                  ) : (
                    rental.item
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {editingId === rental.id ? (
                    <input
                      type="text"
                      value={editForm?.unit}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, unit: e.target.value} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    />
                  ) : (
                    rental.unit
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {editingId === rental.id ? (
                    <input
                      type="number"
                      value={editForm?.price}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, price: Number(e.target.value)} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    />
                  ) : (
                    `$${rental.price}`
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {editingId === rental.id ? (
                    <input
                      type="date"
                      value={editForm?.dateOut}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, dateOut: e.target.value} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    />
                  ) : (
                    rental.dateOut
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {editingId === rental.id ? (
                    <input
                      type="date"
                      value={editForm?.dateBack}
                      onChange={(e) => setEditForm(prev => prev ? {...prev, dateBack: e.target.value} : null)}
                      className="rounded-md border border-gray-300 px-3 py-1"
                    />
                  ) : (
                    rental.dateBack
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex space-x-2">
                    {editingId === rental.id ? (
                      <button
                        onClick={handleSave}
                        className="text-green-600 hover:text-green-900"
                      >
                        <Save className="w-5 h-5" />
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={() => handleEdit(rental)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handlePrintReceipt(rental)}
                          className="text-blue-600 hover:text-blue-900"
                          title="Print Receipt"
                        >
                          <Printer className="w-5 h-5" />
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => handleDelete(rental.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showReceipt && currentReceipt && (
        <Receipt
          receipt={currentReceipt}
          onClose={() => setShowReceipt(false)}
        />
      )}
    </div>
  )
}
