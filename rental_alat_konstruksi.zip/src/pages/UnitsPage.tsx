import { useEffect, useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { Unit } from '../types/types'

export default function UnitsPage() {
  const [units, setUnits] = useState<Unit[]>([])
  const [newUnit, setNewUnit] = useState({ name: '', description: '' })

  useEffect(() => {
    const savedUnits = localStorage.getItem('units')
    if (savedUnits) {
      setUnits(JSON.parse(savedUnits))
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const unit: Unit = {
      id: Date.now().toString(),
      ...newUnit
    }
    const updatedUnits = [...units, unit]
    setUnits(updatedUnits)
    localStorage.setItem('units', JSON.stringify(updatedUnits))
    setNewUnit({ name: '', description: '' })
  }

  const handleDelete = (id: string) => {
    const updatedUnits = units.filter(unit => unit.id !== id)
    setUnits(updatedUnits)
    localStorage.setItem('units', JSON.stringify(updatedUnits))
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Unit Management</h1>
        <p className="mt-2 text-gray-600">Manage your rental units</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Unit Name</label>
            <input
              type="text"
              value={newUnit.name}
              onChange={(e) => setNewUnit({ ...newUnit, name: e.target.value })}
              required
              placeholder="e.g., Hours, Days, Weeks"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <input
              type="text"
              value={newUnit.description}
              onChange={(e) => setNewUnit({ ...newUnit, description: e.target.value })}
              required
              placeholder="Brief description of the unit"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>
        <button
          type="submit"
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Unit
        </button>
      </form>

      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {units.map((unit) => (
              <tr key={unit.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{unit.name}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{unit.description}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <button
                    onClick={() => handleDelete(unit.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
