import { useEffect, useState } from 'react'
import RentalForm from '../components/RentalForm'
import Receipt from '../components/Receipt'
import { RentalEntry, Customer, Receipt as ReceiptType } from '../types/types'
import { ShoppingCart, Trash2 } from 'lucide-react'
import { formatRupiah } from '../utils/formatCurrency'

export default function RentalsPage() {
  const [rentals, setRentals] = useState<RentalEntry[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('')
  const [showReceipt, setShowReceipt] = useState(false)
  const [currentReceipt, setCurrentReceipt] = useState<ReceiptType | null>(null)

  useEffect(() => {
    const savedCustomers = localStorage.getItem('customers')
    if (savedCustomers) setCustomers(JSON.parse(savedCustomers))
  }, [])

  const handleAddRental = (rental: RentalEntry) => {
    if (!selectedCustomerId) {
      alert('Please select a customer first')
      return
    }
    setRentals([...rentals, { ...rental, customerId: selectedCustomerId }])
  }

  const handleDeleteRental = (id: string) => {
    setRentals(rentals.filter(rental => rental.id !== id))
  }

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId)
    return customer ? customer.name : 'Unknown Customer'
  }

  const calculateTotal = () => {
    return rentals.reduce((sum, rental) => {
      const days = rental.totalDays || 1;
      return sum + (rental.price * rental.quantity * days);
    }, 0);
  }

  const handleCheckout = () => {
    if (rentals.length === 0) return
    if (!selectedCustomerId) {
      alert('Please select a customer before checkout')
      return
    }

    const total = calculateTotal()

    const receipt: ReceiptType = {
      id: `R${Date.now()}`,
      date: new Date().toISOString(),
      customerName: getCustomerName(selectedCustomerId),
      items: [...rentals],
      subtotal: total,
      tax: 0,
      total: total
    }

    setCurrentReceipt(receipt)
    setShowReceipt(true)

    // Save to localStorage
    const savedRentals = localStorage.getItem('rentals') || '[]'
    const allRentals = [...JSON.parse(savedRentals), ...rentals]
    localStorage.setItem('rentals', JSON.stringify(allRentals))
  }

  const handleCloseReceipt = () => {
    setShowReceipt(false)
    setRentals([]) // Clear the cart after checkout
    setSelectedCustomerId('') // Reset selected customer
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">New Rental</h1>
        <p className="mt-2 text-gray-600">Create a new equipment rental</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <RentalForm onAdd={handleAddRental} />
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Current Cart</h2>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Customer</label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
            >
              <option value="">Choose a customer</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </select>
          </div>

          {rentals.length > 0 ? (
            <>
              <div className="space-y-4 mb-6">
                {rentals.map((rental) => (
                  <div key={rental.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h3 className="font-medium">{rental.item}</h3>
                      <p className="text-sm text-gray-600">
                        {rental.quantity} x {formatRupiah(rental.price)}/{rental.unit} x {rental.totalDays} days
                      </p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="font-medium">
                        {formatRupiah(rental.quantity * rental.price * (rental.totalDays || 1))}
                      </span>
                      <button
                        onClick={() => handleDeleteRental(rental.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total:</span>
                  <span>{formatRupiah(calculateTotal())}</span>
                </div>

                <button
                  onClick={handleCheckout}
                  className="mt-4 w-full inline-flex justify-center items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Checkout
                </button>
              </div>
            </>
          ) : (
            <p className="text-center text-gray-500 py-8">
              Cart is empty. Add items using the form.
            </p>
          )}
        </div>
      </div>

      {showReceipt && currentReceipt && (
        <Receipt
          receipt={currentReceipt}
          onClose={handleCloseReceipt}
        />
      )}
    </div>
  )
}
