import { Customer, Machine, Unit, RentalEntry } from '../types/types'

export const initialCustomers: Customer[] = [
  {
    id: '1',
    name: 'John Construction Co.',
    address: '123 Builder Street, Construction City',
    phone: '555-0123'
  },
  {
    id: '2',
    name: 'Smith Contractors Ltd.',
    address: '456 Development Road, Builder Town',
    phone: '555-0124'
  },
  {
    id: '3',
    name: 'Elite Builders Inc.',
    address: '789 Construction Avenue, Work City',
    phone: '555-0125'
  }
]

export const initialMachines: Machine[] = [
  {
    id: '1',
    name: 'Excavator CAT 320',
    description: 'Medium-sized hydraulic excavator',
    status: 'available'
  },
  {
    id: '2',
    name: 'Bulldozer D6',
    description: 'Track-type bulldozer for earthmoving',
    status: 'available'
  },
  {
    id: '3',
    name: 'Concrete Mixer 5000',
    description: 'Large capacity concrete mixing truck',
    status: 'available'
  },
  {
    id: '4',
    name: 'Crane LIEBHERR LTM',
    description: 'Mobile crane with telescopic boom',
    status: 'maintenance'
  }
]

export const initialUnits: Unit[] = [
  {
    id: '1',
    name: 'Hour',
    description: 'Hourly rental rate'
  },
  {
    id: '2',
    name: 'Day',
    description: 'Daily rental rate (8 working hours)'
  },
  {
    id: '3',
    name: 'Week',
    description: 'Weekly rental rate (5 working days)'
  },
  {
    id: '4',
    name: 'Month',
    description: 'Monthly rental rate (20 working days)'
  }
]

export const initialRentals: RentalEntry[] = [
  {
    id: '1',
    item: 'Excavator CAT 320',
    unit: 'Day',
    price: 450,
    quantity: 5,
    dateOut: '2024-02-01',
    dateBack: '2024-02-05',
    customerId: '1'
  },
  {
    id: '2',
    item: 'Bulldozer D6',
    unit: 'Week',
    price: 2200,
    quantity: 2,
    dateOut: '2024-02-10',
    dateBack: '2024-02-24',
    customerId: '2'
  },
  {
    id: '3',
    item: 'Concrete Mixer 5000',
    unit: 'Day',
    price: 350,
    quantity: 3,
    dateOut: '2024-02-15',
    dateBack: '2024-02-17',
    customerId: '3'
  }
]

export const initializeData = () => {
  // Only initialize if data doesn't exist
  if (!localStorage.getItem('customers')) {
    localStorage.setItem('customers', JSON.stringify(initialCustomers))
  }
  if (!localStorage.getItem('machines')) {
    localStorage.setItem('machines', JSON.stringify(initialMachines))
  }
  if (!localStorage.getItem('units')) {
    localStorage.setItem('units', JSON.stringify(initialUnits))
  }
  if (!localStorage.getItem('rentals')) {
    localStorage.setItem('rentals', JSON.stringify(initialRentals))
  }
}
