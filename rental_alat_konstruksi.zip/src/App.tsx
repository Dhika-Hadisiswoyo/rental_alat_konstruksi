import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './index.css'
import Layout from './components/Layout'
import RentalsPage from './pages/RentalsPage'
import RentalHistoryPage from './pages/RentalHistoryPage'
import MachinesPage from './pages/MachinesPage'
import CustomersPage from './pages/CustomersPage'
import UnitsPage from './pages/UnitsPage'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<RentalsPage />} />
          <Route path="/history" element={<RentalHistoryPage />} />
          <Route path="/machines" element={<MachinesPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/units" element={<UnitsPage />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App
