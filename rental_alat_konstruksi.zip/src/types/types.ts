export interface RentalEntry {
  id: string;
  item: string;
  unit: string;
  price: number;
  quantity: number;
  dateOut: string;
  dateBack: string;
  customerId: string;
  totalDays?: number;
}

export interface Machine {
  id: string;
  name: string;
  description: string;
  status: 'available' | 'in-use' | 'maintenance';
}

export interface Customer {
  id: string;
  name: string;
  address: string;
  phone: string;
}

export interface Unit {
  id: string;
  name: string;
  description: string;
}

export interface Receipt {
  id: string;
  date: string;
  customerName: string;
  items: RentalEntry[];
  subtotal: number;
  tax: number;
  total: number;
}
