import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { RentalEntry, Machine, Unit } from '../types/types';
import { formatRupiah } from '../utils/formatCurrency';

interface RentalFormProps {
  onAdd: (rental: RentalEntry) => void;
}

export default function RentalForm({ onAdd }: RentalFormProps) {
  
  const [machines, setMachines] = useState<Machine[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [formData, setFormData] = useState({
    item: '',
    unit: '',
    price: '',
    quantity: '1',
    dateOut: '',
    dateBack: '',
    customerId: '',
  });

  useEffect(() => {
    
    const savedMachines = localStorage.getItem('machines');
    const savedUnits = localStorage.getItem('units');
    
    
    if (savedMachines) setMachines(JSON.parse(savedMachines));
    if (savedUnits) setUnits(JSON.parse(savedUnits));
  }, []);

  const calculateDays = (dateOut: string, dateBack: string) => {
    const start = new Date(dateOut);
    const end = new Date(dateBack);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // Minimum 1 day
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const days = calculateDays(formData.dateOut, formData.dateBack);
    const newRental: RentalEntry = {
      id: Date.now().toString(),
      item: formData.item,
      unit: formData.unit,
      price: Number(formData.price),
      quantity: Number(formData.quantity),
      dateOut: formData.dateOut,
      dateBack: formData.dateBack,
      customerId: formData.customerId,
      totalDays: days,
    };
    onAdd(newRental);
    setFormData({
      ...formData,
      item: '',
      unit: '',
      price: '',
      quantity: '1',
    });
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl space-y-4 bg-white p-6 rounded-lg shadow-sm">
      <div className="grid grid-cols-2 gap-4">
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Machine</label>
          <select
            value={formData.item}
            onChange={(e) => setFormData({ ...formData, item: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          >
            <option value="">Select a machine</option>
            {machines.map((machine) => (
              <option key={machine.id} value={machine.name}>
                {machine.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Unit</label>
          <select
            value={formData.unit}
            onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          >
            <option value="">Select a unit</option>
            {units.map((unit) => (
              <option key={unit.id} value={unit.name}>
                {unit.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Quantity</label>
          <input
            type="number"
            min="1"
            value={formData.quantity}
            onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Price per Unit</label>
          <input
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Date Out</label>
          <input
            type="date"
            value={formData.dateOut}
            onChange={(e) => setFormData({ ...formData, dateOut: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Date Back</label>
          <input
            type="date"
            value={formData.dateBack}
            onChange={(e) => setFormData({ ...formData, dateBack: e.target.value })}
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>
      <button
        type="submit"
        className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add to Cart
      </button>
    </form>
  );
}
