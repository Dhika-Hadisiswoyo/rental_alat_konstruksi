import { Trash2 } from 'lucide-react';
import { RentalEntry } from '../types/types';

interface RentalListProps {
  rentals: RentalEntry[];
  onDelete: (id: string) => void;
  getCustomerName: (customerId: string) => string;
}

export default function RentalList({ rentals, onDelete, getCustomerName }: RentalListProps) {
  return (
    <div className="w-full max-w-2xl">
      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Machine</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Out</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Back</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rentals.map((rental) => (
              <tr key={rental.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getCustomerName(rental.customerId)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{rental.item}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.unit}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${rental.price}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.dateOut}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.dateBack}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <button
                    onClick={() => onDelete(rental.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
