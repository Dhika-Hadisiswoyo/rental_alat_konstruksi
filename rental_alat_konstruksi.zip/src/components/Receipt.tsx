import { Receipt as ReceiptType } from '../types/types';
import { useRef } from 'react';
import { Printer } from 'lucide-react';
import { formatRupiah } from '../utils/formatCurrency';

interface ReceiptProps {
  receipt: ReceiptType;
  onClose: () => void;
}

export default function Receipt({ receipt, onClose }: ReceiptProps) {
  const receiptRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    const printContent = receiptRef.current?.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=400');
    
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Print Receipt</title>
            <style>
              @page {
                margin: 0;
                size: 58mm auto;
              }
              @media print {
                body {
                  font-family: 'Courier New', Courier, monospace;
                  width: 58mm;
                  margin: 0;
                  padding: 4mm;
                }
                .receipt {
                  width: 100%;
                  max-width: 384px;
                }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .border-top { border-top: 1px dashed #000; }
                .mt-2 { margin-top: 8px; }
                .mb-2 { margin-bottom: 8px; }
                .text-xs { font-size: 12px; }
                .font-bold { font-weight: bold; }
                p { margin: 4px 0; }
                table { width: 100%; }
                td { vertical-align: top; }
                .item-name { font-weight: bold; }
                .item-details { font-size: 11px; }
                .total { font-size: 14px; font-weight: bold; }
              }
            </style>
          </head>
          <body>
            ${printContent}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg max-w-sm w-full">
        <div ref={receiptRef} className="receipt font-mono text-sm" style={{ width: '384px' }}>
          <div className="text-center mb-4">
            <h2 className="text-lg font-bold">CV CAHAYA MENTARI</h2>
            <p className="text-xs">Equipment Rental Receipt</p>
            <p className="text-xs">{new Date(receipt.date).toLocaleString('id-ID')}</p>
          </div>

          <div className="text-xs mb-4">
            <p>Customer: {receipt.customerName}</p>
            <p>Receipt #: {receipt.id}</p>
          </div>

          <div className="border-t border-b border-dashed py-2">
            {receipt.items.map((item) => (
              <div key={item.id} className="mb-2">
                <div className="item-name">{item.item}</div>
                <div className="item-details text-gray-600">
                  <table>
                    <tr>
                      <td>{item.quantity} x {formatRupiah(item.price)}/{item.unit}</td>
                      <td className="text-right">{formatRupiah(item.quantity * item.price)}</td>
                    </tr>
                    <tr>
                      <td>Days: {item.totalDays}</td>
                      <td className="text-right">{formatRupiah(item.quantity * item.price * (item.totalDays || 1))}</td>
                    </tr>
                  </table>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-2">
            <div className="flex justify-between total border-t border-dashed mt-2 pt-2">
              <span>Total:</span>
              <span>{formatRupiah(receipt.total)}</span>
            </div>
          </div>

          <div className="text-center mt-4 text-xs">
            <p>Thank you for your business!</p>
            <p>Please keep this receipt for your records.</p>
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-4">
          <button
            onClick={handlePrint}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <Printer className="w-4 h-4 mr-2" />
            Print
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
