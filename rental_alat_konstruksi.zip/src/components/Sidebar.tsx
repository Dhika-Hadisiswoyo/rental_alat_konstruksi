import { NavLink } from 'react-router-dom'
import { Construction, Users, ClipboardList, History, Box } from 'lucide-react'

export default function Sidebar() {
  const navItems = [
    { to: '/', icon: ClipboardList, label: 'New Rental' },
    { to: '/history', icon: History, label: 'Rental History' },
    { to: '/machines', icon: Construction, label: 'Machines' },
    { to: '/customers', icon: Users, label: 'Customers' },
    { to: '/units', icon: Box, label: 'Units' },
  ]

  return (
    <div className="w-64 bg-white border-r border-gray-200 px-3 py-4 space-y-2">
      <div className="px-3 py-3 mb-6">
        <h1 className="text-xl font-bold text-gray-900">CV CAHAYA MENTARI</h1>
        <p>Equipment Rentals</p>
      </div>
      
      {navItems.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) =>
            `flex items-center px-3 py-2 rounded-md transition-colors ${
              isActive
                ? 'bg-blue-50 text-blue-700'
                : 'text-gray-700 hover:bg-gray-100'
            }`
          }
        >
          <item.icon className="w-5 h-5 mr-3" />
          <span>{item.label}</span>
        </NavLink>
      ))}
    </div>
  )
}
